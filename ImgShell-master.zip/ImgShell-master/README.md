Ready for implementation.

![Implementation](https://cdn.discordapp.com/attachments/701477293238910997/718420738024931378/unknown.png)

If you want to use script, you have to change some variables. I was inspired by this [article](http://pentestmonkey.net/cheat-sheet/shells/reverse-shell-cheat-sheet).
